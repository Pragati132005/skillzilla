export * from './localStorageAdapter';
